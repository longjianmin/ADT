#ifndef TREE_H_INCLUDED
#define TREE_H_INCLUDED

struct TreeNode;
typedef struct TreeNode *PtrToNode;
typedef PtrToNode SearchTree;
typedef int ElementType;

SearchTree MakeEmpty( SearchTree T );

SearchTree Find( ElementType x , SearchTree T );
SearchTree FindMax( SearchTree T );
SearchTree FindMin( SearchTree T );

SearchTree Insert(ElementType x , SearchTree T );
SearchTree Delete(ElementType x , SearchTree T );
ElementType Retrieve( SearchTree T );

struct TreeNode
{
    ElementType     Element;
    SearchTree      Left;
    SearchTree      Right;
};


#endif // TREE_H_INCLUDED

