#include "Tree.c"

int main()
{
    SearchTree S = NULL ;
    //printf("====1==\n");
    S = MakeEmpty( S );
    //printf("====2==\n");
//    int i , j ; 
//    for(i = 0 , j = 13 ; i < 13 , j > 0; i++ ,j-- ){
//    	S = Insert(i,S);
//    	S = Insert(j,S);
//	}
	S = Insert(6,S);
	S = Insert(8,S);
	S = Insert(2,S);
	S = Insert(5,S);
	S = Insert(1,S);
	S = Insert(3,S);
	S = Insert(4,S);
	Delete(5,S);
    if( S == NULL )
		printf("*******\n");
    if(Find(5,S) == NULL )
        printf("%d",FindMax(S)->Element);
    else
    	printf("=========\n");
    return 0;
}
