#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include "Tree.h"

SearchTree MakeEmpty( SearchTree T )
{
    if( T != NULL ){
        MakeEmpty(T->Left);
        MakeEmpty(T->Right);
        T = NULL;
    }
    return NULL;
}

SearchTree Find( ElementType x , SearchTree T )
{
    if( T == NULL )
        return NULL;
    if( x < T->Element )
        return Find(x , T->Left );
    else
    if( x > T->Element )
        return Find( x , T->Right );
    return T;
}

SearchTree FindMax( SearchTree T )
{
    //printf("===%d===\n",T->Element);
    if( T != NULL )
        while( T->Right != NULL )
            T = T->Right;
    return T;
}

SearchTree FindMin( SearchTree T )
{
    printf("===%d===\n",T->Element);
    if( T == NULL )
        return T;
    else
    if( T->Left == NULL )
        return T;
    else
        return FindMin( T->Left);
}

SearchTree Insert(ElementType x , SearchTree T )
{
    //printf("========\n");
    if( T == NULL )
    {
        T = malloc( sizeof( SearchTree ) );
        T->Element = x;
        printf("==%d\n",T->Element);
        T->Left = T->Right = NULL ;
    }
    else
    if( T->Element < x )
        T->Right = Insert(x , T->Right );
    else
    if( T->Element > x )
        T->Left = Insert(x , T->Left );
    return T;
}

SearchTree Delete(ElementType x , SearchTree T ){
    SearchTree TmpCell ;
    if( T == NULL )
        return NULL;
}

ElementType Retrieve( SearchTree T )
{

}
