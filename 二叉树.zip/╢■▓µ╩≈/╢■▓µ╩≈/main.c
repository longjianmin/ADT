#include "Tree.c"

int main()
{
    SearchTree S = NULL;
    Insert(1,S);
    Insert(123,S);
    Insert(12345,S);
    Insert(1234567,S);
    //if(FindMin(S) != NULL )
        //printf("%d",FindMax(S)->Element);
    return 0;
}
